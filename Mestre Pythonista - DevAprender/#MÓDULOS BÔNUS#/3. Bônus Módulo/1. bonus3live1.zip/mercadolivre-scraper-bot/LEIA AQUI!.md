# Como usar este projeto
0. 
1. Recomendo assistir a live para entender melhor como utilizar esse projeto
    * Existem 2 formas de conseguir assistir a live:
        1. Ter assistido AO VIVO no youtube
        2. Ser aluno da [Dev Aprender](http://cursodepython.net/) (se for, provavelmente está lendo isso dentro da plataforma de estudo :D )
3. Seu chromedriver precisa estar atualizado corretamente, aprenda fazer isso aqui
2. Não esqueça de [se inscrever](https://www.youtube.com/devaprender) para acompanhar as próximas lives

# Quer se tornar um Pythonista Profissional e entrar para o mercado?
[Domine Python profissionalmente aqui](http://cursodepython.net/)