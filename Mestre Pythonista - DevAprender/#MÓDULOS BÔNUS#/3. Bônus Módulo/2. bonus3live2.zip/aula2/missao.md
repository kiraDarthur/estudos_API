# 🔴 APP de INVESTIMENTOS do ZERO - 100% no Terminal com Python - CRUD Python

Essa aplicação deve nos permitir, 100% através do terminal. Listar, editar, criar e excluir investimentos, além de ser esteticamente interessante e com música para acompanhar, ao final iremos criar um executável

😎 - Apresentação no terminal da sua APP
😎 - Criar um arquivo JSON de investimentos com python
😎 - Ler arquivo JSON de investimentos existentes com python
😎 - Apresentar quanto já foi investido até o momento
😎 - Listar os primeiros 5 investimentos
😎 - Apresentar um menu de escolhas(Listar todos, editar, excluir e criar)
😎 - Permitir listar todos investimentos existentes
😎 - Permitir editar investimentos existentes
😎 - Permitir excluir investimentos existentes
😎 - Permitir criar novos investimentos
😎 - Permitir que uma música seja tocada, sempre que seu programa iniciar
✅ - Criar um executável para que o programa possa rodar em outros computadores
