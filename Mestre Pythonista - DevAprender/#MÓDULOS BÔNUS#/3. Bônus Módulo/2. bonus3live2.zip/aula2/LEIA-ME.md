# Quer se tornar um programador Python do ZERO?
* Acesse https://cursodepython.net/
Use o cupom natal10 para ganhar 10% de desconto! Válido apenas até este natal de 2020!