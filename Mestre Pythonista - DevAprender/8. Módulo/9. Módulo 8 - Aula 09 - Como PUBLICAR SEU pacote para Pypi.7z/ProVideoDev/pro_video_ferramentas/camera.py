def tirar_foto():
    print('Tirando foto!')