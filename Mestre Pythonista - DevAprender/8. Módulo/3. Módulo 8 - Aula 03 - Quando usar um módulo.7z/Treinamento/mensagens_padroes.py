boas_vindas = 'Olá seja bem vindo a DevAprender.com'
novo_usuario = 'Olá, bem vindo a esta aplicação'
falha_cadastro = 'Seu cadastro não foi possível, favor tentar novamente'
