def buscar_usuario():
    pass

def alterar_usuarios():
    pass

def excluir_usuario():
    pass