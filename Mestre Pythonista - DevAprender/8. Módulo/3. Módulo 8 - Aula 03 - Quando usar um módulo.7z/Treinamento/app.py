# Quando usar módulos
# 1° - Separar funcionalidades relacionadas
# 2° - Não acoplar o seu código
# 3° - Não ter um arquivo gigante
from banco_de_dados import buscar_usuario
from configuracoes import senha
from xxxx import a,b,c,d

buscar_usuario()
print(senha)
    
