senha = '1234ASD!'
email_pessoal = 'jhonatan@gmail.com'
conexoes_maximas = 5

def obter_senha():
    senha = 'F!R#RD'
    return senha

