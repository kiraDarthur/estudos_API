class Camera():
    def __init__(self, resolucao_maxima):
        resolucao_maxima = resolucao_maxima

    def tirar_foto(self):
        print('Tirando foto')

    def aumentar_zoom(self):
        print('Aumentando zoom')

    def diminuir_zoom(self):
        print('Diminuir zoom')
