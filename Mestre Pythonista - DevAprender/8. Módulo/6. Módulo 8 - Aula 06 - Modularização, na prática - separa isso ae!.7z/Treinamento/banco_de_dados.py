def iniciar_banco_de_dados():
    print('Iniciando conexao')
    print('Criando tabelas iniciais')


def buscar_usuarios():
    print('Buscando usuários')
