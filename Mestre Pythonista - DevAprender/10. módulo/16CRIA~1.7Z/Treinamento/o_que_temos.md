# Nossa estrutura atual:

1. Nós já temos uma classe que representa uma postagem no nosso blog
2. Nós já temos uma classe que representa um autor no nosso blog
3. Nos resta agora fazer o seguinte:
    1. Criar uma api para criar novos autores
    2. Criar uma api para criar novas postagens
    3. Adicionar banco de dados a cada chamado do nosso api
    4. Adicionar autenticação a nossas apis de postagem e autores
4. No próximo vídeo iremos criar uma api para criar novos autores
5. No próximo vídeo iremos criar uma api para criar novas postagens